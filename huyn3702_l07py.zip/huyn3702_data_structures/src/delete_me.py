"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Benjamin Huynh
ID:      169053702
Email:   huyn3702@mylaurier.ca
__updated__ = "2024-02-29"
-------------------------------------------------------
"""
# Imports
from List_linked import List
# Constants

thing = List()
thing1 = List()
thing2 = List()

thing1.append(11)
thing1.append(22)
thing1.append(33)
thing1.append(44)
thing1.append(55)

thing2.append(44)
thing2.append(55)
thing2.append(66)
thing2.append(77)
thing2.append(88)

thing.union_r(thing2, thing1)
print(thing._count)

for v in thing:
    print(v)
