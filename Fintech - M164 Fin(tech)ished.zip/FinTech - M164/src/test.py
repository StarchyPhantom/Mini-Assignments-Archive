"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Benjamin Huynh
ID:      169053702
Email:   huyn3702@mylaurier.ca
__updated__ = "2024-02-26"
-------------------------------------------------------
"""
# Imports
from Processor import Processor
# Constants


test = Processor(True)

test.insert("you")
test.insert("love")
test.insert("I")

print(test.write("sus"))
