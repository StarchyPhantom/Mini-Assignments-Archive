/**
 * -------------------------------------
 * @file  hash.c
 * file description
 * -------------------------------------
 * @author your name, your id, your email
 *
 * @version 2025-03-16
 *
 * -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hash.h"

HNODE* hashtable_search(HASHTABLE *ht, char *name) {
// your code
	HNODE *cur = *(ht->hna + hash(name, ht->size));

	while (cur) {
		if (strcmp(cur->data.name, name) == 0) {
			return cur;
		}
		cur = cur->next;
	}

	return NULL;
}

int hashtable_insert(HASHTABLE *ht, DATA data) {
// your code
	HNODE *cur = *(ht->hna + hash(data.name, ht->size));
	if (cur == NULL) {
		cur = malloc(sizeof(*cur));
		cur->data = data;
		cur->next = NULL;
		*(ht->hna + hash(cur->data.name, ht->size)) = cur;
		ht->count++;
		//printf("AAAAAAAAAAAAAAA %s", cur->data.name);
		return 1;
	}

	HNODE *prev = NULL;

	while (cur) {
		if (strcmp(cur->data.name, data.name) == 0) {
			cur->data.value = data.value;
			return 0;
		}
		prev = cur;
		cur = cur->next;
	}

	cur = malloc(sizeof(*cur));
	cur->data = data;
	cur->next = NULL;
	prev->next = cur;
	ht->count++;
	return 1;
}

int hashtable_delete(HASHTABLE *ht, char *name) {
// your code
	HNODE *cur = *(ht->hna + hash(name, ht->size));

	while (cur) {
		if (strcmp(cur->data.name, name) == 0) {
			HNODE *temp = cur;
			cur = cur->next;
			free(temp);
			*(ht->hna + hash(name, ht->size)) = cur;
			ht->count--;
			return 1;
		}
		cur = cur->next;
	}
	return 0;
}

int hash(char *key, int size) {
	unsigned int hash = 0;
	while (*key) {
		hash += *key++;
	}
	return hash % size;
}

HASHTABLE* new_hashtable(int size) {
	HASHTABLE *ht = (HASHTABLE*) malloc(sizeof(HASHTABLE));
	ht->hna = (HNODE**) malloc(sizeof(HNODE**) * size);
	int i;
	for (i = 0; i < size; i++)
		*(ht->hna + i) = NULL;

	ht->size = size;
	ht->count = 0;
	return ht;
}

void hashtable_clean(HASHTABLE **htp) {
	if (*htp == NULL)
		return;
	HASHTABLE *ht = *htp;
	HNODE *p, *temp;
	int i;
	for (i = 0; i < ht->size; i++) {
		p = ht->hna[i];
		while (p) {
			temp = p;
			p = p->next;
			free(temp);
		}
		ht->hna[i] = NULL;
	}
	free(ht->hna);
	ht->hna = NULL;
	*htp = NULL;
}
