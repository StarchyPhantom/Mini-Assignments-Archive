package cp213;

/**
 * Implements a Popularity Tree. Extends BST.
 *
 * @author your name here
 * @author David Brown
 * @version 2024-10-15
 */
public class PopularityTree<T extends Comparable<T>> extends BST<T> {

    /**
     * Auxiliary method for valid. May force node rotation if the retrieval count of
     * the located node data is incremented.
     *
     * @param node The node to examine for key.
     * @param key  The data to search for. Count is updated to count in matching
     *             node data if key is found.
     * @return The updated node.
     */
    private TreeNode<T> retrieveAux(TreeNode<T> node, final CountedData<T> key) {
	
	// your code here
	
	if (node == null)
	{
	    return null;
	}
	
	final int comp = node.getData().compareTo(key);
	this.comparisons++;
	
	TreeNode<T> result;
	
	if (comp > 0) {
	    // General case - check the left subtree.
	    result = retrieveAux(node.getLeft(), key);
	    
	    if (result != null && node.getLeft().getData().getCount() < result.getData().getCount())
	    {
		node.setLeft(result);
	    }
	    
	    if (result != null && node.getData().getCount() < node.getLeft().getData().getCount())
	    {
		node = rotateRight(node);
		
		if (this.root == node.getRight())
		{
		    this.root = node;
		}
	    }
	    
	     
	} else if (comp < 0) {
	    // General case - check the right subtree.
	    //System.out.println(node.getRight());
	    result = retrieveAux(node.getRight(), key);
	    
	    if (result != null && node.getRight().getData().getCount() < result.getData().getCount())
	    {
		node.setRight(result);
	    }
	    
	    if (result != null && node.getData().getCount() < node.getRight().getData().getCount())
	    {
		node = rotateLeft(node);
		
		if (this.root == node.getLeft())
		{
		    this.root = node;
		}
	    }
	    
	    //System.out.println(node);
	    
	} else {
	    // Base case - data is already in the tree, increment its count
	    node.getData().incrementCount();
	    result = node;
	}
	node.updateHeight();
	result.updateHeight();
	return result;
    }

    /**
     * Performs a left rotation around node.
     *
     * @param parent The subtree to rotate.
     * @return The new root of the subtree.
     */
    private TreeNode<T> rotateLeft(final TreeNode<T> parent) {

	// your code here
	TreeNode<T> result = parent.getRight();
	
	if (result.getLeft() != null)
	{
	    parent.setRight(result.getLeft());
	    result.setLeft(parent);
	}
	else
	{
	    result.setLeft(parent);
	    parent.setRight(null);
	}
	
	
	parent.updateHeight();
	return result;
    }
    
    

    /**
     * Performs a right rotation around {@code node}.
     *
     * @param parent The subtree to rotate.
     * @return The new root of the subtree.
     */
    private TreeNode<T> rotateRight(final TreeNode<T> parent) {

	// your code here
	TreeNode<T> result = parent.getLeft();
	
	if (result.getRight() != null)
	{
	    parent.setLeft(result.getRight());
	    result.setRight(parent);
	}
	else
	{
	    result.setRight(parent);
	    parent.setLeft(null);
	}
	
	parent.updateHeight();
	return result;
    }

    /**
     * Replaces BST insertAux - does not increment count on repeated insertion.
     * Counts are incremented only on retrieve.
     */
    @Override
    protected TreeNode<T> insertAux(TreeNode<T> node, final CountedData<T> data) {
	// your code here
	if (node == null) {
	    // Base case - add a new node containing the data.
	    node = new TreeNode<T>(data);
	    this.size++;
	} else {
	    // Compare the node data against the insert data.
	    final int result = node.getData().compareTo(data);

	    if (result > 0) {
		// General case - check the left subtree.
		node.setLeft(this.insertAux(node.getLeft(), data));
	    } else if (result < 0) {
		// General case - check the right subtree.
		node.setRight(this.insertAux(node.getRight(), data));
	    } 
	}
	node.updateHeight();
	return node;
    }

    /**
     * Auxiliary method for valid. Determines if a subtree based on node is a valid
     * subtree. An Popularity Tree must meet the BST validation conditions, and
     * additionally the counts of any node data must be greater than or equal to the
     * counts of its children.
     *
     * @param node The root of the subtree to test for validity.
     * @return true if the subtree base on node is valid, false otherwise.
     */
    @Override
    protected boolean isValidAux(final TreeNode<T> node, TreeNode<T> minNode, TreeNode<T> maxNode) {

	// your code here
	if (node == null)
	{
	    return true;
	}
	
	if (minNode == null)
	{
	    minNode = node;
	    
	    while (minNode.getLeft() != null)
	    {
		minNode = (minNode.getLeft());
	    }
	}
	
	if (maxNode == null)
	{
	    maxNode = node;
	    
	    while (maxNode.getRight() != null)
	    {
		maxNode = (maxNode.getRight());
	    }
	}
	
	if (node.getData().compareTo(minNode.getData()) == 0)
	{
	    return true;
	}
	
	if (node.getData().compareTo(maxNode.getData()) == 0)
	{
	    return true;
	}
	
	boolean result = true;
	
	if (node.getLeft() != null)
	{
	    if (node.getData().compareTo(node.getLeft().getData()) <= 0)
	    {
		return false;
	    }
	    
	    if (node.getData().getCount() < node.getLeft().getData().getCount())
	    {
		return false;
	    }
	    
	    result = this.isValidAux(node.getLeft(), minNode, maxNode);
	}
	
	if (result && node.getRight() != null)
	{
	    if (node.getData().compareTo(node.getRight().getData()) >= 0)
	    {
		return false;
	    }
	    
	    if (node.getData().getCount() < node.getRight().getData().getCount())
	    {
		return false;
	    }
	    
	    result = this.isValidAux(node.getLeft(), minNode, maxNode);
	}

	return result;
    }

    /**
     * Determines whether two PopularityTrees are identical.
     *
     * @param target The PopularityTree to compare this PopularityTree against.
     * @return true if this PopularityTree and target contain nodes that match in
     *         position, data, count, and height, false otherwise.
     */
    public boolean equals(final PopularityTree<T> target) {
	return super.equals(target);
    }

    /**
     * Very similar to the BST retrieve, but increments the data count here instead
     * of in the insertion.
     *
     * @param key The key to search for.
     */
    @Override
    public CountedData<T> retrieve(CountedData<T> key) {

	// your code here
	TreeNode<T> result = retrieveAux(this.root, key);
	
	if (result == null)
	{
	    return null;
	}
	
	return result.getData();
    }

}
