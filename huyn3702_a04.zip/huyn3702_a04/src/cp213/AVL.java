package cp213;

/**
 * Implements an AVL (Adelson-Velsky Landis) tree. Extends BST.
 *
 * @author your name here
 * @author David Brown
 * @version 2024-10-15
 */
public class AVL<T extends Comparable<T>> extends BST<T> {

    /**
     * Returns the balance data of node. If greater than 1, then left heavy, if less
     * than -1, then right heavy. If in the range -1 to 1 inclusive, the node is
     * balanced. Used to determine whether to rotate a node upon insertion.
     *
     * @param node The TreeNode to analyze for balance.
     * @return A balance number.
     */
    private int balance(final TreeNode<T> node) {

	// your code here
	int result = 0;
	
	if (node.getRight() != null)
	{
	    result -= node.getRight().getHeight();
	}
	
	if (node.getLeft() != null)
	{
	    result += node.getLeft().getHeight();
	}
	
	//System.out.println(result);
	return result;
    }

    /**
     * Rebalances the current node if its children are not balanced.
     *
     * @param node the node to rebalance
     * @return replacement for the rebalanced node
     */
    private TreeNode<T> rebalance(TreeNode<T> node) {

	// your code here

	//Left
	if (balance(node) > 1) 
	{ 
	    if (balance(node.getLeft()) < 0) 
	    {
		node.setLeft(rotateLeft(node.getLeft()));
	    }
	    return rotateRight(node);
	} 
	//Right
	else if (balance(node) < -1) 
	{ 
	    if (balance(node.getRight()) > 0) 
	    {
		node.setRight(rotateRight(node.getRight()));
	    }
	    return rotateLeft(node);
	}

	return node; // Already balanced
    }

    /**
     * Performs a left rotation around node.
     *
     * @param node The subtree to rotate.
     * @return The new root of the subtree.
     */
    private TreeNode<T> rotateLeft(final TreeNode<T> node) {

	// your code here
	TreeNode<T> result = node.getRight();
	
	if (result.getLeft() != null)
	{
	    node.setRight(result.getLeft());
	    result.setLeft(node);
	}
	else
	{
	    result.setLeft(node);
	    node.setRight(null);
	}
	
	
	node.updateHeight();
	result.updateHeight();
	return result;
	
    }

    /**
     * Performs a right rotation around node.
     *
     * @param node The subtree to rotate.
     * @return The new root of the subtree.
     */
    private TreeNode<T> rotateRight(final TreeNode<T> node) {

	// your code here
	TreeNode<T> result = node.getLeft();
	
	if (result.getRight() != null)
	{
	    node.setLeft(result.getRight());
	    result.setRight(node);
	}
	else
	{
	    result.setRight(node);
	    node.setLeft(null);
	}
	
	node.updateHeight();
	result.updateHeight();
	return result;
    }

    /**
     * Auxiliary method for insert. Inserts data into this AVL. Same as BST
     * insertion with addition of rebalance of nodes.
     *
     * @param node The current node (TreeNode).
     * @param data Data to be inserted into the node.
     * @return The inserted node.
     */
    @Override
    protected TreeNode<T> insertAux(TreeNode<T> node, final CountedData<T> data) {

	// your code here
	//System.out.println("-----");
	if (node == null) {
	    // Base case - add a new node containing the data.
	    node = new TreeNode<T>(data);
	    node.getData().incrementCount();
	    this.size++;
	} else {
	    // Compare the node data against the insert data.
	    final int result = node.getData().compareTo(data);

	    if (result > 0) {
		// General case - check the left subtree.
		node.setLeft(this.insertAux(node.getLeft(), data));
	    } else if (result < 0) {
		// General case - check the right subtree.
		node.setRight(this.insertAux(node.getRight(), data));
	    } else {
		// Base case - data is already in the tree, increment its count
		node.getData().incrementCount();
	    }
	    
	    node = rebalance(node);
	}
	node.updateHeight();
	return node;
    }

    /**
     * Auxiliary method for valid. Determines if a subtree based on node is a valid
     * subtree. An AVL must meet the BST validation conditions, and additionally be
     * balanced in all its subtrees - i.e. the difference in height between any two
     * children must be no greater than 1.
     *
     * @param node The root of the subtree to test for validity.
     * @return true if the subtree base on node is valid, false otherwise.
     */
    @Override
    protected boolean isValidAux(final TreeNode<T> node, TreeNode<T> minNode, TreeNode<T> maxNode) {

	// your code here
	if (node == null)
	{
	    return true;
	}
	
	if (minNode == null)
	{
	    minNode = node;
	    
	    while (minNode.getLeft() != null)
	    {
		minNode = (minNode.getLeft());
	    }
	}
	
	if (maxNode == null)
	{
	    maxNode = node;
	    
	    while (maxNode.getRight() != null)
	    {
		maxNode = (maxNode.getRight());
	    }
	}
	
	if (node.getData().compareTo(minNode.getData()) == 0)
	{
	    return true;
	}
	
	if (node.getData().compareTo(maxNode.getData()) == 0)
	{
	    return true;
	}
	
	boolean result = true;
	
	if (node.getLeft() != null)
	{
	    if (node.getData().compareTo(node.getLeft().getData()) <= 0)
	    {
		return false;
	    }
	    
	    result = this.isValidAux(node.getLeft(), minNode, maxNode);
	}
	
	if (result && node.getRight() != null)
	{
	    if (node.getData().compareTo(node.getRight().getData()) >= 0)
	    {
		return false;
	    }
	    result = this.isValidAux(node.getLeft(), minNode, maxNode);
	}
	
	if (!(this.balance(node) >= -1 && this.balance(node) <= 1))
	{
	    return false;
	}

	return result;
    }

    /**
     * Determines whether two AVLs are identical.
     *
     * @param target The AVL to compare this AVL against.
     * @return true if this AVL and target contain nodes that match in position,
     *         data, count, and height, false otherwise.
     */
    public boolean equals(final AVL<T> target) {
	return super.equals(target);
    }

    /**
     * Auxiliary method for remove. Removes data from this BST. Same as BST removal
     * with addition of rebalance of nodes.
     *
     * @param node The current node (TreeNode).
     * @param data Data to be removed from the tree.
     * @return The replacement node.
     */
    @Override
    protected TreeNode<T> removeAux(TreeNode<T> node, final CountedData<T> data) {

	// your code here
	if (node == null) {
	    return node;
	}

	final int result = node.getData().compareTo(data);

	if (result > 0) {
	    // General case - check the left subtree.
	    node.setLeft(removeAux(node.getLeft(), data));
	} else if (result < 0) {
	    // General case - check the right subtree.
	    node.setRight(removeAux(node.getRight(), data));
	} else {
	    // Base case - data is in the tree
	    this.size--;
	    if (node.getLeft() == null)
	    {
		return node.getRight();
	    }

	    if (node.getRight() == null)
	    {
		return node.getLeft();
	    }

	    //Both children exist
	    TreeNode<T> temp = node.getRight();
	    
	    while (temp.getLeft() != null)
	    {
		temp = temp.getLeft();
	    }
	    
	    temp.setLeft(node.getLeft());
	    
	    node = node.getRight();
	}
	
	node = rebalance(node);
	node.updateHeight();
	return node;
    }

}
