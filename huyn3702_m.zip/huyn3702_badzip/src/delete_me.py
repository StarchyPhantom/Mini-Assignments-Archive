"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Benjamin Huynh
ID:      169053702
Email:   huyn3702@mylaurier.ca
__updated__ = "2024-02-28"
-------------------------------------------------------
"""
# Imports
from Sorted_Set_array import Sorted_Set
# Constants

test = Sorted_Set()

test.add(11)
test.add(22)
test.add(33)

test2 = Sorted_Set()

test2.add(11)
test2.add(22)
test2.add(33)
test2.add(44)
test2.add(55)

print("start")
for v in test2.symmetric_difference(test):
    print(v)
print("done")
