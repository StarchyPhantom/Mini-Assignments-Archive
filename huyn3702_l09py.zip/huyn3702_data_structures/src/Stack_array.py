"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Benjamin Huynh
ID:      169053702
Email:   huyn3702@mylaurier.ca
__updated__ = "2024-01-26"
-------------------------------------------------------
"""
# Imports
from copy import deepcopy
# Constants


class Stack:
    """
    Defines an ADT of a Stack, with the functions: ...
    """

    def __init__(self):
        """
        -------------------------------------------------------
        Initializes an empty stack. Data is stored in a Python list.
        Use: stack = Stack()
        -------------------------------------------------------
        Returns:
            a new Stack object (Stack)
        -------------------------------------------------------
        """
        self._values = []

    def is_empty(self):
        empty = False

        if len(self._values) == 0:
            empty = True

        return empty

    def push(self, value):
        """
        -------------------------------------------------------
        Pushes a copy of value onto the top of the stack.
        Use: stack.push(value)
        -------------------------------------------------------
        Parameters:
            value - value to be added to stack (?)
        Returns:
            None
        -------------------------------------------------------
        """
        self._values.append(deepcopy(value))
        return

    def pop(self):
        assert len(self._values) > 0, "Cannot pop from an empty stack"
        if not self.is_empty():
            thing = self._values.pop(len(self._values) - 1)
            return thing

    def peek(self):
        assert len(self._values) > 0, "Cannot peek from an empty stack"
        if not self.is_empty():
            thing = deepcopy(self._values[len(self._values) - 1])
            return thing

    def combine(self, source1, source2):
        """
        -------------------------------------------------------
        Combines two source stacks into the current target stack.
        When finished, the contents of source1 and source2 are interlaced
        into target and source1 and source2 are empty.
        Use: target.combine(source1, source2)
        -------------------------------------------------------
        Parameters:
            source1 - an array-based stack (Stack)
            source2 - an array-based stack (Stack)
        Returns:
            None
        -------------------------------------------------------
        """
        while not len(source1._values) == 0 or not len(source2._values) == 0:
            if not len(source1._values) == 0:
                self._values.append(source1._values.pop())
            if not len(source2._values) == 0:
                self._values.append(source2._values.pop())

        return

    def reverse(self):
        """
        -------------------------------------------------------
        Reverses the contents of the source stack.
        Use: source.reverse()
        -------------------------------------------------------
        Returns:
            None
        -------------------------------------------------------
        """
        self._values.reverse()

        return
