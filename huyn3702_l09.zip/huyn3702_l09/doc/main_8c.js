var main_8c =
[
    [ "MAX_STRING", "main_8c.htm#ab5187269936538ffb8ccbbe7115ffdbc", null ],
    [ "SEP", "main_8c.htm#a95cf1ca63ff303311d342d1a53d51f38", null ],
    [ "main", "main_8c.htm#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "test_heap", "main_8c.htm#a6133809891ed454b26638e3c8919a908", null ]
];