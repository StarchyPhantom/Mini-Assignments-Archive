"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Benjamin Huynh
ID:      169053702
Email:   huyn3702@mylaurier.ca
__updated__ = "2024-03-08"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST
from morse import fill_letter_bst, encode_morse, DATA1, decode_morse, fill_code_bst
# Constants

thing = BST()

fill_letter_bst(thing, DATA1)

for v in thing:
    print(v)

print(encode_morse(thing, "This is a string"))

thing = BST()

temp = """- .... .. ... 
.. ... 
.- 
... - .-. .. -. --. """

fill_code_bst(thing, DATA1)

print(decode_morse(thing, temp))
