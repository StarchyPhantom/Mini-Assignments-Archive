"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Benjamin Huynh
ID:      169053702
Email:   huyn3702@mylaurier.ca
__updated__ = "2024-03-22"
-------------------------------------------------------
"""
# Imports

# Constants


import test_Sorts_array
print("""n:   100       |      Comparisons       | |         Swaps          |
Algorithm      In Order Reversed   Random In Order Reversed   Random
-------------- -------- -------- -------- -------- -------- --------""")
for i in range(0, len(test_Sorts_array.SORTS)):
    test_Sorts_array.test_sort(
        test_Sorts_array.SORTS[i][0], test_Sorts_array.SORTS[i][1])
