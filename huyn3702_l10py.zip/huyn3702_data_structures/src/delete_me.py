"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Benjamin Huynh
ID:      169053702
Email:   huyn3702@mylaurier.ca
__updated__ = "2024-03-22"
-------------------------------------------------------
"""
# Imports
"""from BST_linked import BST
from morse import fill_letter_bst, encode_morse, DATA1, decode_morse, fill_code_bst
# Constants

thing = BST()

fill_letter_bst(thing, DATA1)

for v in thing:
    print(v)

print(encode_morse(thing, "This is a string"))

thing = BST()

temp = - .... .. ... 
.. ... 
.- 
... - .-. .. -. --. 

fill_code_bst(thing, DATA1)

print(decode_morse(thing, temp))


from List_linked import List
thing = List()
thing1 = List()
a = List()

thing.insert(0, 11)
thing.insert(0, 22)
thing.insert(0, 33)
thing1.insert(0, 44)
thing1.insert(0, 55)

a.combine(thing, thing1)

for v in a:
    print(v)


from Sorted_List_linked import Sorted_List
thing = Sorted_List()
thing1 = Sorted_List()
a = Sorted_List()

thing.insert(11)
thing.insert(22)
thing.insert(33)
thing.insert(44)

thing1.insert(11)
thing1.insert(22)
thing1.insert(33)
thing1.insert(44)

cur = thing._front
for i in range(0, thing._count):
    print(cur._value)
    cur = cur._next

a.intersection(thing, thing1)

for v in a:
    print(v)


from Food import Food
import Food_utilities
from Hash_Set_array import Hash_Set
file = open("foods.txt", "r", encoding="utf-8")
values = Food_utilities.read_foods(file)
values = []

for i in range(0, 101):
    values.append(i)

values.append(11)
values.append(22)
values.append(33)
values.append(44)
values.append(55)

thing = Hash_Set(5)

for v in values:
    thing.insert(v)

thing.debug()

# thing._rehash()

# thing.debug()
"""


import test_Sorts_List_linked
print(test_Sorts_List_linked.SORTS[0][0])
input()
test_Sorts_List_linked.test_sort(
    test_Sorts_List_linked.SORTS[0][0], test_Sorts_List_linked.SORTS[0][1])
