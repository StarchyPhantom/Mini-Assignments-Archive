"""
-------------------------------------------------------
HSJ_Linked
-------------------------------------------------------
Author: BENJAMIN HUYNH
ID: 169053702
Email: huyn3702@mylaurier.ca
__updated__ = ""
-------------------------------------------------------

Name: The "Hop Skip Jump" Linked List Problem
Created By: Jason Van Humbeck
Package: Laurier FinTech CP164 Mock Exam - Part 1

Task Description:
    This problem involves manipulating a basic singly linked list with a twist.
    Each node in the list has a type representing the action to take when it is read:
    - "Jump": You read and output the current node.
    - "Skip": You ignore the current node and move to the next one.
    - "Hop": You read and output the next node (but do not change the index).

    For example, if the list is {Jump "Apple"} -> {Skip "Orange:"} -> {Hop "Grape"} -> {Jump "Pineapple"}:
    - RESULT: "APPLE, PINEAPPLE, PINEAPPLE"

Requirements:
    - No imported classes allowed.
    - Prohibit the use of loop breaks.
    - No illegal aids.
"""

from copy import deepcopy


class List:
    def insert(self, typ, value, i):
        """
        -------------------------------------------------------
        Inserts a new node into the list at a specified index.
        Any index of i is valid, where:
            i < 0 -> i = 0
            i > count -> i = count
        Use: lst.insert(typ, value, i)
        -------------------------------------------------------
        Parameters:
            typ - the type of the new node (int: 0 for Skip, 1 for Jump, 2 for Hop)
            value - the value of the new node (any)
            i - the index to insert the new node at (int)
        Returns:
            None
        -------------------------------------------------------
        """

        # Your Code Here
        if i >= self._count:
            end = _Node(typ, deepcopy(value), None)
            if self._rear is not None:
                self._rear._next = end
            if self._front is None:
                self._front = end
            self._rear = end
            self._count += 1
        elif i <= 0:
            if self._front is not None:
                front = end = _Node(typ, deepcopy(value), self._front)
            else:
                front = _Node(typ, deepcopy(value), None)
            if self._rear is None:
                self._rear = front
            self._front = front
            self._count += 1
        else:
            prev = self._front

            for j in range(0, i - 1):
                prev = prev._next

            cur = _Node(typ, deepcopy(value), prev._next)
            prev._next = cur

            self._count += 1

        return

    def remove_skip(self):
        """
        -------------------------------------------------------
        Removes all Skip nodes from the list and returns the values removed.
        Use: removed = lst.remove_skip()
        -------------------------------------------------------
        Returns:
            removed - the concatenated values of all Skip nodes removed (str)
        -------------------------------------------------------
        """
        # Your Code Here
        sent = ""

        prev = None
        cur = self._front

        while cur is not None:
            if cur._type == 0:
                if prev is None:
                    self._front = cur._next
                    if self._front is None:
                        self._rear = None
                else:
                    prev._next = cur._next
                    if prev._next is None:
                        self._rear = prev
                sent += cur._value
            prev = cur
            cur = cur._next

        return sent

    def export(self):
        """
        -------------------------------------------------------
        Creates a string using the rules and guidelines of
        "Hop, Skip, Jump" and returns it
        Use: exp = lst.export()
        -------------------------------------------------------
        Returns:
            exp - a string containing the concatenated values of all Jump and Hop nodes (str)
        -------------------------------------------------------
        """
        # Your Code Here
        sent = ""

        cur = self._front

        while cur is not None:
            if cur._type == 1:
                sent += cur._value
            elif cur._type == 2:
                if cur._next is not None:
                    sent += cur._next._value
            cur = cur._next

        return sent

    # DO NOT CHANGE CODE BELOW THIS LINE
    # =======================================================================
    def test(self):
        """
        -------------------------------------------------------
        Creates a string containing the type and value of all nodes in the list.
        Use: test_str = lst.test()
        -------------------------------------------------------
        Returns:
            test_str - a string containing the type and value of all nodes in the list (str)
        -------------------------------------------------------
        """
        out = ""
        node = self._front
        while node != None:
            out += f'{node.printin()}'
            node = node._next
        return out

    def print(self):
        """
        -------------------------------------------------------
        Creates a string containing the type and value of all nodes in the list with arrows between them.
        Use: print_str = lst.print()
        -------------------------------------------------------
        Returns:
            print_str - a string containing the type and value of all nodes in the list with arrows (str)
        -------------------------------------------------------
        """
        out = ""
        node = self._front
        while node != None:
            out += f'{node.printout()}'
            if (node._next != None):
                out += " -> "
            node = node._next
        return out

    def clean(self):
        """
        -------------------------------------------------------
        Removes all nodes from the list.
        Use: lst.clean()
        -------------------------------------------------------
        Returns:
            None
        -------------------------------------------------------
        """
        self._front = None
        self._rear = None
        self._count = 0

    def __init__(self):
        """
        -------------------------------------------------------
        Initializes an empty list.
        Use: lst = List()
        -------------------------------------------------------
        Returns:
            A new List object (List)
        -------------------------------------------------------
        """
        self._front = None
        self._rear = None
        self._count = 0


class _Node:
    def __init__(self, typ, value, next_):
        """
        -------------------------------------------------------
        Initializes a list node with a value and link to the next node.
        Use: node = _Node(typ, value, next_)
        -------------------------------------------------------
        Parameters:
            typ - the type of the new node (int: 0 for Skip, 1 for Jump, 2 for Hop)
            value - the value of the new node (any)
            next_ - another list node (_Node)
        Returns:
            A new _Node object (_Node)
        -------------------------------------------------------
        """
        self._type = typ
        self._value = deepcopy(value)
        self._next = next_

    def printout(self):
        """
        -------------------------------------------------------
        Creates a formatted string representation of the node including its type and value.
        Use: out_str = node.printout()
        -------------------------------------------------------
        Returns:
            out_str - a formatted string including the type and value of the node (str)
        -------------------------------------------------------
        """
        out = ""
        if self._type == 0:
            out += "{(Skip)"
        elif self._type == 1:
            out += "{(Jump)"
        elif self._type == 2:
            out += "{(Hop)"
        else:
            out += "{(ERROR)}"

        out += deepcopy(f', \"{self._value}\"')
        out += "}"
        return out

    def printin(self):
        """
        -------------------------------------------------------
        Creates a formatted string representation of the node including its type and value without brackets.
        Use: out_str = node.printin()
        -------------------------------------------------------
        Returns:
            out_str - a formatted string including the type and value of the node without brackets (str)
        -------------------------------------------------------
        """
        out = ""
        if self._type == 0:
            out += "s"
        elif self._type == 1:
            out += "j"
        elif self._type == 2:
            out += "h"
        else:
            out += "e"

        out += deepcopy(f'{self._value}')
        return out
