var structgraph__am =
[
    [ "size", "structgraph__am.htm#a2a6d395298b0d369d8e44c64aa7ca6ba", null ],
    [ "values", "structgraph__am.htm#accf22c8395e2913e82b39133d4a86ef5", null ]
];