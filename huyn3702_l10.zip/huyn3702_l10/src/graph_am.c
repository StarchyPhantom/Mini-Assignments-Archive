/**
 * -------------------------------------
 * @file  graph_am.c
 * Adjacency Matrix Graph Code File
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2025-01-06
 *
 * -------------------------------------
 */
#include "graph_am.h"

// Initializes an adjacency matrix graph.
graph_am* graph_am_initialize(int size) {
	graph_am *source = malloc(sizeof *source);
	source->size = size;
	// Initialize values to zeroes.
	source->values = calloc(size * size, sizeof *source->values);
	return source;
}

void graph_am_free(graph_am **source) {
	// Free up the data array.
	free((*source)->values);
	(*source)->values = NULL;
	free(*source);
	*source = NULL;
	return;
}

int graph_am_add_vertice(graph_am *source, const graph_am_pair *pair) {
	// your code here
	if (pair->col == pair->row) {
		if (*(source->values + pair->col + (pair->row * source->size)) == 0) {
			*(source->values + pair->col + (pair->row * source->size)) = 2;
		} else {
			return 0;
		}
	} else {
		if (*(source->values + pair->col + (pair->row * source->size)) == 0) {
			*(source->values + pair->col + (pair->row * source->size)) = 1;
			*(source->values + pair->row + (pair->col * source->size)) = 1;
		} else {
			return 0;
		}
	}

	return 1;
}

int graph_am_remove_vertice(graph_am *source, const graph_am_pair *pair) {
	if (pair->col == pair->row) {
		if (*(source->values + pair->col + (pair->row * source->size)) != 0) {
			*(source->values + pair->col + (pair->row * source->size)) = 0;
		} else {
			return 0;
		}
	} else {
		if (*(source->values + pair->col + (pair->row * source->size)) != 0) {
			*(source->values + pair->col + (pair->row * source->size)) = 0;
			*(source->values + pair->row + (pair->col * source->size)) = 0;
		} else {
			return 0;
		}
	}

	return 1;
}

graph_am* graph_am_create(int size, const graph_am_pair pairs[], int count) {
	graph_am *source = graph_am_initialize(size);

	// your code here
	for (int i = 0; i < count; i++) {
		if (pairs[i].col == pairs[i].row) {
			*(source->values + pairs[i].col + (pairs[i].row * size)) = 2;
		} else {
			*(source->values + pairs[i].col + (pairs[i].row * size)) = 1;
			*(source->values + pairs[i].row + (pairs[i].col * size)) = 1;
		}
	}

	return source;
}

void graph_am_neighbours(const graph_am *source, int vertex, int vertices[],
		int *count) {

	// your code here
	for (int i = 0; i < source->size; i++) {
		if (*(source->values + source->size * vertex + i) != 0) {
			vertices[*count] = i;
			*count += 1;
		}
	}
	return;
}

int graph_am_degree(const graph_am *source, int vertex) {
	int connected = 0;

	// your code here
	for (int i = 0; i < source->size; i++) {
		connected += *(source->values + source->size * vertex + i);
	}

	return connected;
}

void graph_am_breadth_traversal(const graph_am *source, int vertex,
		int vertices[], int *count) {

	// your code here
	vertices[*count] = vertex;
	*count += 1;
	int tempVert[source->size];
	int tempCount = 0;

	int visited[source->size];
	visited[vertex] = 1;
	//graph_am_neighbours(source, vertex, vertices, count);

	for (int i = 0; i < *count; i++) {
		graph_am_neighbours(source, vertices[i], tempVert, &tempCount);
		for (int j = 0; j < tempCount; j++) {

			if (visited[tempVert[j]] != 1) {
				visited[tempVert[j]] = 1;
				vertices[*count] = tempVert[j];
				*count += 1;
			}
		}
		int tempVert[source->size];
		tempCount = 0;
	}
	return;
}

void graph_am_depth_traversal(const graph_am *source, int vertex,
		int vertices[], int *count) {

	// your code here
	vertices[*count] = vertex;
	*count += 1;
	int tempVert[source->size];
	int tempCount = 0;

	int visited[source->size];
	visited[vertex] = 1;

	for (int i = 0; i < *count; i++) {
		graph_am_neighbours(source, vertices[i], tempVert, &tempCount);
		for (int j = tempCount - 1; j >= 0; j--) {

			if (visited[tempVert[j]] != 1) {
				visited[tempVert[j]] = 1;
				vertices[*count] = tempVert[j];
				*count += 1;
			}
		}
		int tempVert[source->size];
		tempCount = 0;
	}
	return;
}

// Prints the contents of an adjacency matrix graph.
void graph_am_print(const graph_am *source) {
// Print the column numbers.
	printf("    ");

	for (int i = 0; i < source->size; i++)
		printf("%3d", i);
	printf("\n");
	printf("    ");
	for (int i = 0; i < source->size; i++)
		printf("---");
	printf("\n");

// Print the row numbers and rows.
	for (int i = 0; i < source->size; i++) {
		printf("%3d|", i);

		for (int j = 0; j < source->size; j++) {
			// find item using offsets
			printf("%3d", *(source->values + i * source->size + j));
		}
		printf("\n");
	}
}
