/**
 * -------------------------------------
 * @file  bst.c
 * file description
 * -------------------------------------
 * @author your name, your id, your email
 *
 * @version 2025-03-07
 *
 * -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bst.h"

BSTNODE* bst_node(RECORD data);
BSTNODE* extract_smallest_node(BSTNODE **rootp);

static BSTNODE* bst_search_aux(BSTNODE *node, char *key) {
	if (node->left != NULL && strcmp(key, node->data.name) < 0) {
		return bst_search_aux(node->left, key);
	}

	if (node->right != NULL && strcmp(key, node->data.name) > 0) {
		return bst_search_aux(node->right, key);
	}
	//printf("%s ", node->data.name);
	if (strcmp(key, node->data.name) == 0) {
		return node;
	}
	return NULL;
}

BSTNODE* bst_search(BSTNODE *root, char *key) {
// your code
	if (root == NULL) {
		return NULL;
	}
	return bst_search_aux(root, key);
}

static void bst_insert_aux(BSTNODE *node, RECORD data) {
	if (strcmp(data.name, node->data.name) < 0) {
		if (node->left != NULL) {
			bst_insert_aux(node->left, data);
		} else {
			node->left = bst_node(data);
		}
	}

	if (strcmp(data.name, node->data.name) > 0) {
		if (node->right != NULL) {
			bst_insert_aux(node->right, data);
		} else {
			node->right = bst_node(data);
		}
	}
}

void bst_insert(BSTNODE **rootp, RECORD data) {
// your code
	if (*rootp == NULL) {
		(*rootp) = bst_node(data);
	}
	bst_insert_aux(*rootp, data);
}

static BSTNODE* bst_delete_aux(BSTNODE *node, char *key) {
	if (node->left != NULL && strcmp(key, node->data.name) < 0) {
		node->left = bst_delete_aux(node->left, key);
	}

	if (node->right != NULL && strcmp(key, node->data.name) > 0) {
		node->right = bst_delete_aux(node->right, key);
	}
	//printf("%s ", node->data.name);
	if (strcmp(key, node->data.name) == 0) {
		BSTNODE *result;
		if (node->right == NULL) {
			if (node->left == NULL) {
				result = NULL;
			}
			result = node->left;
		} else if (node->left == NULL) {
			result = node->right;
		} else {
			result = node->right;
			BSTNODE *temp = NULL;

			while (result->left) {
				temp = result;
				result = result->left;
			}

			if (temp != NULL) {
				temp->left = NULL;
			}

			result->left = node->left;
			result->right = node->right;
		}
		free(node);
		return result;
	}

	return node;
}

void bst_delete(BSTNODE **rootp, char *key) {
// your code
	if (*rootp) {
		*rootp = bst_delete_aux(*rootp, key);
	}
}

BSTNODE* bst_node(RECORD data) {
	BSTNODE *np = (BSTNODE*) malloc(sizeof(BSTNODE));
	if (np) {
		memcpy(np, &data, sizeof(BSTNODE));
		np->left = NULL;
		np->right = NULL;
	}
	return np;
}

void bst_clean(BSTNODE **rootp) {
	BSTNODE *root = *rootp;
	if (root) {
		if (root->left)
			bst_clean(&root->left);
		if (root->right)
			bst_clean(&root->right);
		free(root);
	}
	*rootp = NULL;
}

BSTNODE* extract_smallest_node(BSTNODE **rootp) {
	BSTNODE *p = *rootp, *parent = NULL;
	if (p) {
		while (p->left) {
			parent = p;
			p = p->left;
		}

		if (parent == NULL)
			*rootp = p->right;
		else
			parent->left = p->right;

		p->left = NULL;
		p->right = NULL;
	}

	return p;
}
