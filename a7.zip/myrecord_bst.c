/**
 * -------------------------------------
 * @file  myrecord_bst.c
 * file description
 * -------------------------------------
 * @author your name, your id, your email
 *
 * @version 2025-03-07
 *
 * -------------------------------------
 */

#include <stdio.h>
#include <math.h>
#include "bst.h"
#include "myrecord_bst.h"

void add_record(BSTDS *ds, RECORD record) {
// your code
	bst_insert(&(ds->root), record);
	float oldMean = ds->mean;
	ds->mean = (ds->mean * ds->count) + record.score;
	ds->count++;
	ds->mean /= ds->count;
	ds->stddev = sqrt(
			((1 / (float) ds->count)
					* ((ds->count - 1) * (pow(ds->stddev, 2) + pow(oldMean, 2))
							+ pow(record.score, 2)) - (pow(ds->mean, 2))));
}

void remove_record(BSTDS *ds, char *name) {
// your code
	BSTNODE *temp = bst_search(ds->root, name);
	if (temp != NULL) {
		float oldMean = ds->mean;
		ds->mean = (ds->mean * ds->count) - temp->data.score;
		ds->count--;
		if (ds->count > 0) {
			ds->mean /= ds->count;
		} else {
			ds->mean = 0.0f;
		}
		if (ds->count <= 1) {
			ds->stddev = 0.0f;
		} else {
			ds->stddev = sqrt(
					((1 / (float) ds->count)
							* ((ds->count + 1)
									* (pow(ds->stddev, 2) + pow(oldMean, 2))
									- pow(temp->data.score, 2))
							- (pow(ds->mean, 2))));

		}
	}
}

void bstds_clean(BSTDS *ds) {
	bst_clean(&ds->root);
	ds->count = 0;
	ds->mean = 0;
	ds->stddev = 0;
}
