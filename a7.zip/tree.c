/**
 * -------------------------------------
 * @file  tree.c
 * file description
 * -------------------------------------
 * @author your name, your id, your email
 *
 * @version 2025-03-04
 *
 * -------------------------------------
 */
#include <stdio.h>
#include <stdlib.h>
#include "queue_stack.h"
#include "tree.h"

TPROPS tree_property(TNODE *root) {
// your code
	TPROPS r = { 0 };
	if (root) {
		//1 . TPROPS lp = the props of left sub-tree
		//2.  TPROPS rp= the props of right sub-tree
		//3.  Compute the r.count, and r.height using lp and rp
		TPROPS temp1 = tree_property(root->left);
		TPROPS temp2 = tree_property(root->right);
		r.order = temp1.order + temp2.order + 1;

		if (temp1.height < temp2.height) {
			r.height = temp2.height + 1;
		} else {
			r.height = temp1.height + 1;
		}
	}
	return r;
}

void preorder(TNODE *root) {
// your code
	if (root != NULL)
		printf("%c ", root->data);

	if (root->left != NULL) {
		preorder(root->left);
	}

	if (root->right != NULL) {
		preorder(root->right);
	}
}

void inorder(TNODE *root) {
// your code
	if (root->left != NULL) {
		inorder(root->left);
	}

	if (root != NULL)
		printf("%c ", root->data);

	if (root->right != NULL) {
		inorder(root->right);
	}
}

void postorder(TNODE *root) {
// your code
	if (root->left != NULL) {
		postorder(root->left);
	}

	if (root->right != NULL) {
		postorder(root->right);
	}

	if (root != NULL)
		printf("%c ", root->data);
}

/*static void tree_bforder_aux(TNODE *node) {
 if (node->left != NULL) {
 printf("%c ", node->left->data);
 }

 if (node->right != NULL) {
 printf("%c ", node->right->data);
 }

 if (node->left != NULL) {
 tree_bforder_aux(node->left);
 }

 if (node->right != NULL) {
 tree_bforder_aux(node->right);
 }
 }*/

void bforder(TNODE *root) {
// your code
	/*if (root != NULL)
	 printf("%c ", root->data);*/
	//tree_bforder_aux(root);
	//NEED TO USE STACK/QUEUE AS PER THE REQUIREMENTS
	QUEUE queue = { 0 };
	enqueue(&queue, root);
	while (queue.front) {
		TNODE *p = (TNODE*) dequeue(&queue);
		printf("%c ", p->data);
		if (p->left) {
			enqueue(&queue, p->left);
		}
		if (p->right) {
			enqueue(&queue, p->right);
		}
	}

}

TNODE* bfs(TNODE *root, char val) {
// your code
	TNODE *r = NULL;
	if (root) {
		QUEUE queue = { 0 };  // auxiliary queue for BST
		enqueue(&queue, root);
		while (queue.front) {
			TNODE *p = (TNODE*) dequeue(&queue);
			if (val == p->data) {
				r = p;
				break;
			}
			if (p->left) {
				enqueue(&queue, p->left);
			}
			if (p->right) {
				enqueue(&queue, p->right);
			}
		}
	}
	return r;
}

TNODE* dfs(TNODE *root, char val) {
// your code
	TNODE *r = NULL;
	if (root) {
		STACK stack = { 0 };
		push(&stack, root);
		while (stack.top) {
			TNODE *p = (TNODE*) pop(&stack);
			if (val == p->data) {
				r = p;
				break;
			}
			if (p->left) {
				push(&stack, p->left);
			}
			if (p->right) {
				push(&stack, p->right);
			}
		}
	}
	return r;
}
// the following functions are given, need to add to your program.

TNODE* tree_node(char val) {
	TNODE *np = (TNODE*) malloc(sizeof(TNODE));
	if (np != NULL) {
		np->data = val;
		np->left = NULL;
		np->right = NULL;
	}
	return np;
}

void clean_tree(TNODE **rootp) {
	TNODE *p = *rootp;
	if (p) {
		if (p->left)
			clean_tree(&p->left);
		if (p->right)
			clean_tree(&p->right);
		free(p);
	}
	*rootp = NULL;
}

void insert_tree(TNODE **rootp, char val) {
	if (*rootp == NULL) {
		*rootp = tree_node(val);
	} else {
		QUEUE queue = { 0 };
		TNODE *p;
		enqueue(&queue, *rootp);
		while (queue.front) {
			p = dequeue(&queue);
			if (p->left == NULL) {
				p->left = tree_node(val);
				break;
			} else {
				enqueue(&queue, p->left);
			}

			if (p->right == NULL) {
				p->right = tree_node(val);
				break;
			} else {
				enqueue(&queue, p->right);
			}
		}
	}
}

