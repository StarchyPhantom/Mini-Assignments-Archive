/**
 * -------------------------------------
 * @file  heap.c
 * file description
 * -------------------------------------
 * @author your name, your id, your email
 *
 * @version 2025-03-20
 *
 * -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "heap.h"

int cmp(KEYTYPE a, KEYTYPE b) {
	int r = 0;
	if (a < b)
		r = -1;
	else if (a > b)
		r = 1;
	return r;
}

HEAP* new_heap(int capacity) {
	HEAP *hp = (HEAP*) malloc(sizeof(HEAP));
	if (hp == NULL)
		return NULL;
	hp->hda = (HEAPDATA*) malloc(sizeof(HEAPDATA) * capacity);
	if (hp->hda == NULL) {
		free(hp);
		return NULL;
	};
	hp->capacity = capacity;
	hp->size = 0;
	return hp;
}

void heap_insert(HEAP *heap, HEAPDATA new_node) {
// your code
	// Add new value to end of the heap.
	if (heap->size == heap->capacity) {
		heap->capacity *= 2;   // this is to reset the capacity double
		HEAPDATA *temp = realloc(heap->hda, sizeof(HEAPDATA) * heap->capacity);
		if (temp) {
			heap->hda = temp;
		} else {
			temp = malloc(sizeof(HEAPDATA) * heap->capacity);
			if (temp) {
				memcpy(temp, heap->hda, sizeof(HEAPDATA) * heap->size);
				free(heap->hda);
				heap->hda = temp;
			} else {
				printf("array resize failed\n");
			}
		}
	}
	heap->hda[heap->size] = new_node;
	heap->size++;
	// Fix the heap.

	int cont = 1;
	while (cont == 1) {
		cont = 0;
		for (int i = 0; i < heap->size; i++) {
			if (heap->hda[((i) - 1) / 2].key > heap->hda[i].key) {
				HEAPDATA temp = heap->hda[((i) - 1) / 2];
				//printf("%d\n", heap->hda[((i) - 1) / 2].value);
				//printf("%d\n", heap->hda[i].value);
				heap->hda[((i) - 1) / 2] = heap->hda[i];
				heap->hda[i] = temp;

				cont = 1;
				break;
			}
		}
	}
	return;
}

HEAPDATA heap_find_min(HEAP *heap) {
// your code
	/*int smallestKey = 0;
	 int index = 0;
	 for (int i = 0; i < heap->size; i++)
	 if (heap->hda[i].key < smallestKey) {
	 smallestKey = heap->hda[i].key;
	 index = i;
	 }*/
	return heap->hda[0];
}

HEAPDATA heap_extract_min(HEAP *heap) {
// your code
	HEAPDATA ans = heap_find_min(heap);
	for (int i = 1; i < heap->size; i++) {
		heap->hda[i - 1] = heap->hda[i];
	}

	heap->size--;

	if (heap->size <= (heap->capacity) / 4 && heap->capacity > 4) {
		heap->capacity /= 2;
	}

	int cont = 1;
	while (cont == 1) {
		cont = 0;
		for (int i = 0; i < heap->size; i++) {
			if (heap->hda[((i) - 1) / 2].key > heap->hda[i].key) {
				HEAPDATA temp = heap->hda[((i) - 1) / 2];
				//printf("%d\n", heap->hda[((i) - 1) / 2].value);
				//printf("%d\n", heap->hda[i].value);
				heap->hda[((i) - 1) / 2] = heap->hda[i];
				heap->hda[i] = temp;

				cont = 1;
				break;
			}

			/*if (i % 2 == 1 && i + 1 < heap->size
			 && (heap->hda[i].key > heap->hda[i + 1].key)) {
			 HEAPDATA temp = heap->hda[i];
			 heap->hda[i] = heap->hda[i + 1];
			 heap->hda[i + 1] = temp;
			 cont = 1;
			 break;
			 }*/
		}
	}

	return ans;
}

int heap_change_key(HEAP *heap, int index, KEYTYPE new_key) {
// your code
	heap->hda[index].key = new_key;

	int parent = (index - 1) / 2;

	if (index > 0 && heap->hda[parent].key > heap->hda[index].key) {
		// up
		while (index > 0
				&& heap->hda[(index - 1) / 2].key > heap->hda[index].key) {
			int p = (index - 1) / 2;
			HEAPDATA temp = heap->hda[p];
			heap->hda[p] = heap->hda[index];
			heap->hda[index] = temp;
			index = p;
		}
	} else {
		// down
		int left, right, smallest;
		while (1) {
			left = 2 * index + 1;
			right = 2 * index + 2;
			smallest = index;

			if (left < heap->size
					&& heap->hda[left].key < heap->hda[smallest].key)
				smallest = left;
			if (right < heap->size
					&& heap->hda[right].key < heap->hda[smallest].key)
				smallest = right;

			if (smallest != index) {
				HEAPDATA temp = heap->hda[index];
				heap->hda[index] = heap->hda[smallest];
				heap->hda[smallest] = temp;
				index = smallest;
			} else {
				break;
			}
		}
	}

	return index;
}

int heap_search_value(HEAP *heap, VALUETYPE data) {
// your code
	for (int i = 0; i < heap->size; i++) {
		if (data == heap->hda[i].value) {
			return i;
		}
	}
	return -1;
}

void heap_sort(HEAPDATA *arr, int n) {
// your code
	int cont = 1;
	while (cont == 1) {
		cont = 0;
		for (int i = 1; i < n; i++) {
			if (arr[i].key > arr[i - 1].key) {
				HEAPDATA temp = arr[i - 1];
				arr[i - 1] = arr[i];
				arr[i] = temp;
				cont = 1;
			}
		}
	}
}

void heap_clean(HEAP **heapp) {
	if (heapp) {
		HEAP *heap = *heapp;
		if (heap->capacity > 0) {
			heap->capacity = 0;
			heap->size = 0;
			free(heap->hda);
			free(heap);
		}
		*heapp = NULL;
	}
}
