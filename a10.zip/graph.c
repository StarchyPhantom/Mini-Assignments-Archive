/**
 * -------------------------------------
 * @file  graph.c
 * file description
 * -------------------------------------
 * @author your name, your id, your email
 *
 * @version 2025-03-25
 *
 * -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "queue_stack.h"
#include "graph.h"

GRAPH* new_graph(int order) {
	GRAPH *gp = malloc(sizeof(GRAPH));
	gp->nodes = malloc(order * sizeof(GNODE*));

	int i;
	for (i = 0; i < order; i++) {
		gp->nodes[i] = malloc(sizeof(GNODE));
		gp->nodes[i]->nid = i;
		strcpy(gp->nodes[i]->name, "null");
		gp->nodes[i]->neighbor = NULL;
	}

	gp->order = order;
	gp->size = 0;

	return gp;
}

void insert_edge_graph(GRAPH *g, int from, int to, int weight) {
// your code
	ADJNODE *ptr;

	ptr = g->nodes[from]->neighbor;
	while (ptr != NULL) {
		//printf("(%d %d %d) ", i, ptr->nid, ptr->weight);
		if (ptr->nid == to) {
			ptr->weight = weight;
			return;
		}
		ptr = ptr->next;
	}

	ADJNODE *ap = malloc(sizeof(ADJNODE));
	ap->nid = to;
	ap->weight = weight;
	ap->next = NULL;
	ptr = g->nodes[from]->neighbor;
	while (ptr && ptr->next) {
		ptr = ptr->next;
	}
	//g->nodes[from]->neighbor
	if (ptr) {
		ptr->next = ap;
	} else {
		g->nodes[from]->neighbor = ap;
	}

	g->size++;
}

void delete_edge_graph(GRAPH *g, int from, int to) {
// your code
	ADJNODE *prev = NULL;
	ADJNODE *ptr;

	ptr = g->nodes[from]->neighbor;
	while (ptr != NULL) {
		if (ptr->nid == to) {
			if (prev) {
				prev->next = ptr->next;
			} else {
				g->nodes[from]->neighbor = ptr->next;
			}
			free(ptr);
			g->size--;
			return;
		}
		prev = ptr;
		ptr = ptr->next;
	}
}

int get_edge_weight(GRAPH *g, int from, int to) {
// your code
	ADJNODE *ptr = g->nodes[from]->neighbor;
	while (ptr) {
		if (ptr->nid == to) {
			return ptr->weight;
		}
		ptr = ptr->next;
	}
	return -1;
}

static void aux_bforder(int visited[], GNODE *ptr, GRAPH *g) {
	printf("(%d %s) ", ptr->nid, ptr->name);
	visited[ptr->nid] = 1;
	ADJNODE *ap = ptr->neighbor;
	while (ap) {
		//printf(" f(%d   %d  v%d)f ", ptr->nid, ap->nid, visited[ap->nid]);
		if (visited[ap->nid] != 1) {
			aux_bforder(visited, g->nodes[ap->nid], g);
		}
		ap = ap->next;
	}
}

void traverse_bforder(GRAPH *g, int nid) {
// your code
	GNODE *ptr = g->nodes[nid];
	/*for (int i = nid; i < g->order; i++) {
	 ptr = g->nodes[i];
	 if (ptr)
	 printf("(%d %s) ", ptr->nid, ptr->name);
	 }*/

	int visited[g->order];

	for (int i = 0; i < g->order; i++) {
		visited[i] = 0;
	}

	aux_bforder(visited, ptr, g);
}

static void aux_dforder(int visited[], GNODE *ptr, GRAPH *g) {
	//printf("(%d %s) ", ptr->nid, ptr->name);
	ADJNODE *ap = NULL;
	int temp = -1;
	ADJNODE *oap = ptr->neighbor;

	while (oap) {
		ap = ptr->neighbor;
		while (ap) {
			//printf(" f(%d   %d  v%d)f ", ptr->nid, ap->nid, visited[ap->nid]);
			if (visited[ap->nid] != 1 && temp < ap->nid) {
				temp = ap->nid;
			}
			ap = ap->next;
		}

		if (temp != -1) {
			visited[temp] = 1;
			//printf(" s(%s)s ", g->nodes[temp]->name);
			printf("(%d %s) ", temp, g->nodes[temp]->name);
			aux_dforder(visited, g->nodes[temp], g);
			//printf(" f(%s)f ", g->nodes[temp]->name);
			//push(sp, temp);

		}

		temp = -1;
		oap = oap->next;
	}
}

// Use auxiliary stack data structure for the algorithm
void traverse_dforder(GRAPH *g, int nid) {
// your code
	GNODE *ptr = g->nodes[nid];

	int visited[g->order];
	STACK *sp = malloc(sizeof(STACK));

	for (int i = 0; i < g->order; i++) {
		visited[i] = 0;
	}

	printf("(%d %s) ", ptr->nid, ptr->name);
	visited[ptr->nid] = 1;

	//push(sp, &ptr->neighbor->nid);
	aux_dforder(visited, ptr, g);

	//int temp;
	/*while (sp && sp->top) {
	 temp = pop(sp);
	 printf("(%d %s) ", temp, g->nodes[temp]->name);
	 }*/
}

void clean_graph(GRAPH **gp) {
	int i;
	GRAPH *g = *gp;
	ADJNODE *temp, *ptr;
	for (i = 0; i < g->order; i++) {
		ptr = g->nodes[i]->neighbor;
		while (ptr != NULL) {
			temp = ptr;
			ptr = ptr->next;
			free(temp);
		}
		free(g->nodes[i]);
	}
	free(g->nodes);
	free(g);
	*gp = NULL;
}

void display_graph(GRAPH *g) {
	if (g) {
		printf("order %d ", g->order);
		printf("size %d ", g->size);
		printf("(from to weight) ");
		int i;
		ADJNODE *ptr;
		for (i = 0; i < g->order; i++) {
			//printf("\n%d:", g->nodes[i]->nid);
			ptr = g->nodes[i]->neighbor;
			while (ptr != NULL) {
				printf("(%d %d %d) ", i, ptr->nid, ptr->weight);
				ptr = ptr->next;
			}
		}
	}
}
