/**
 * -------------------------------------
 * @file  edgelist.c
 * file description
 * -------------------------------------
 * @author your name, your id, your email
 *
 * @version 2025-03-24
 *
 * -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include "edgelist.h"

EDGELIST* new_edgelist() {
	EDGELIST *tp = malloc(sizeof(EDGELIST));
	tp->size = 0;
	tp->start = NULL;
	tp->end = NULL;
	return tp;
}

void insert_edge_end(EDGELIST *g, int from, int to, int weight) {
// your code
	EDGENODE *ep = malloc(sizeof(EDGENODE));
	ep->from = from;
	ep->to = to;
	ep->weight = weight;
	ep->next = NULL;
	if (g->size > 0) {
		g->end->next = ep;
	} else {
		g->start = ep;
	}
	g->end = ep;
	g->size++;
}

void insert_edge_start(EDGELIST *g, int from, int to, int weight) {
// your code;
	EDGENODE *ep = malloc(sizeof(EDGENODE));
	ep->from = from;
	ep->to = to;
	ep->weight = weight;
	ep->next = NULL;
	if (g->size == 0) {
		g->end = ep;
	}
	ep->next = g->start;
	g->start = ep;
	g->size++;
}

void delete_edge(EDGELIST *g, int from, int to) {
// your code
	EDGENODE *prev = NULL;
	EDGENODE *cur = g->start;

	while (cur) {
		if (cur->from == from && cur->to == to) {
			if (prev) {
				prev->next = cur->next;
			} else {
				g->start = cur->next;
			}

			if (cur == g->end) {
				g->end = prev;
			}

			g->size--;
			break;
		}
		prev = cur;
		cur = cur->next;
	}
}

int weight_edgelist(EDGELIST *g) {
// your code
	int sum = 0;
	EDGENODE *cur = g->start;

	while (cur) {
		sum += cur->weight;
		cur = cur->next;
	}

	return sum;
}

void clean_edgelist(EDGELIST **gp) {
	EDGELIST *g = *gp;
	EDGENODE *temp, *p = g->start;
	while (p) {
		temp = p;
		p = p->next;
		free(temp);
	}
	free(g);
	*gp = NULL;
}

void display_edgelist(EDGELIST *g) {
	if (g == NULL)
		return;
	printf("size %d ", g->size);
	printf("(from to weight) ");
	EDGENODE *p = g->start;
	while (p) {
		printf("(%d %d %d) ", p->from, p->to, p->weight);
		p = p->next;
	}
}
